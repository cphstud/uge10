public class Controller{
  final int PRCVAT = 25;
  final String MSG = "MOMS";
  final String WELCOMEMSG = "Velkommen til momsberegneren";
  final String CURRENCY = "Kr";
  private String question;
  Dialog myDialog;
  ComputeVAT computeVAT;
  ViewVAT viewVAT;

  public Controller() {
    this.myDialog = new Dialog(WELCOMEMSG);
    //double userIn = doDiag();
    this.computeVAT = new ComputeVAT(PRCVAT);
    //double moms = doVAT(userIn);
    this.viewVAT = new ViewVAT(MSG,CURRENCY);
    //doView(moms,MSG);
  }

  public void runController() {
    String question = "Indtast varens pris: ";
    double retVal = myDialog.doDiag(question);
    double moms = computeVAT.doVAT(retVal);
    viewVAT.doView(moms,MSG);
  }
}
